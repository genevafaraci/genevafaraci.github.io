#TO DO LIST
- [x] go over color choices
- [x] update icon for tab
- [ ] embbed resume (LinkdIn API)
- [x] update about me page
- [x] remove instagram social media link on all pages
- [x] link needed social media sites
- [x] add icon to tab

#Time Line 
- [x] update links to featured work
- [x] figure out best way to host papers
- [x] fix tags on timeline
- [x] link all needed documents
- [x] upload and link all code/projects

#Lab Requirement
- [ ] form validation
- [x] Inveractive Nav
- [x] javascript plug-in